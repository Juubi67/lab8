import { Component } from '@angular/core';

@Component({
  standalone: true,
  selector: 'students',
  template: '<h2>{{ getTitle() }} - {{getCurrentDate()}}</h2>',
})
export class StudentComponent {
  title = 'My List of students';

  getTitle() {
    return this.title;
  }

  getCurrentDate() {
    const currentDate = new Date();
    return currentDate.toDateString();
  }
}
