import { Component, NgModule } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { StudentComponent } from './students.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, StudentComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  title = 'student-app';
}
