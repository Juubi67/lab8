import { Component } from '@angular/core';

@Component({
  standalone: true,
  selector: 'students',
  template: '<h2>Students</h2>',
})
export class StudentComponent {}
